// Desinstala el modo sin conexión de la versión anterior y limpia su caché.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil((async () => {
  const ks = await caches.keys();
  await Promise.all(ks.map((k) => caches.delete(k)));
  await self.registration.unregister();
  const cs = await self.clients.matchAll();
  cs.forEach((c) => c.navigate(c.url));
})()));
